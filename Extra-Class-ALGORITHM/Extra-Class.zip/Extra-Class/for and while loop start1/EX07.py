for i in range(9):
    if i <5:
        print(i)