number =0
while number <=10:
    if number %2 ==1:
        print(number)
    number +=1