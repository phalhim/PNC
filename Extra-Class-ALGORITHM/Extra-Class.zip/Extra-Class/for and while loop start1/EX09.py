number =0
while number<10:
    if number >5:
        print(number)
    number +=1