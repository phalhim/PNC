for i in range(9):
    if i % 2 ==0:
        print(i)