number =0
while number <=9:
    print(number)
    number +=1
 