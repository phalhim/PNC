number ="123"
i = 0
sum = 0
while i < len(number):
    sum +=int(number[i])
    i += 1
print(sum)