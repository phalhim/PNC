number =0
while number <=9:
    if number % 2 ==0:
        print(number)
    number +=1