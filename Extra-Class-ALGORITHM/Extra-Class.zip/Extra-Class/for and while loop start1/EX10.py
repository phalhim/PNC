number ="123"
n=0
for i in range(len(number)):
    n  += int(number[i])
print(n)
