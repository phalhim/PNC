text="Hello world"
print(text)