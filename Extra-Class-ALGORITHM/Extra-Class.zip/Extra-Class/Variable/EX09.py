yon ="Yen Yon"
him ="Hey Him"
rady ="Y Rady"
print(yon,him,rady)