textlnut1 = "Study hard and well done"
print(textlnut1)