text ="word"
print(text)