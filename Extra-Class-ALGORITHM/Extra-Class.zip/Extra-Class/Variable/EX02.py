text = "HELLO CAMBODIA"
print(text)