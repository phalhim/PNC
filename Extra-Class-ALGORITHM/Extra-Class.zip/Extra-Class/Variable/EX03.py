world ="Hello worid"
print(world)