number = 15
input(number)