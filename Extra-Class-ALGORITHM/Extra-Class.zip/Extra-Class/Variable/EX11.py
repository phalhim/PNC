number1 = 8
number2 =2
print(number1+number2)
print(number1-number2)
print(number1*number2)
print(number1/number2)