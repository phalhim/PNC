isFemale = True
isMale = False
print(str(isFemale)+" and "+str(isMale))