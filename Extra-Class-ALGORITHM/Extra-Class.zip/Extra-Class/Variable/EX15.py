text ="hello"
result =0
for i in range(len(text)):
    result +=1
print(result)