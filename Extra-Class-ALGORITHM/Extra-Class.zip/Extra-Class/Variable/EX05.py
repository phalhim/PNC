number =12
print(number)