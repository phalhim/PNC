number =100
print(number)