number1 =10
number2 = 11
result ="I am a teacher"
if number2 >number1:
    result ="I am student"
print(result)
