textInput = "NO"
if 1<10:
    textInput ="OK"
print(textInput)