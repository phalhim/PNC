#4 - Using while loop, loop 10 times display number > 5 and < 10
number = 5
while  number >= 5 and number <9:
    number +=1
    print(number)