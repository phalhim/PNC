#3 - Using while loop, loop 10 times display number from 20 - 30
number =20
while number<=30:
    print(number)
    number +=1
