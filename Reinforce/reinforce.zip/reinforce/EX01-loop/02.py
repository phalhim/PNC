#2 - Repeat 10 times and display number from 10 to 1
for i in reversed(range(1,11)):
    print(i)