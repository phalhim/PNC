#4 - How many even number in string
text = "1423789"
even = 0
for i in range(len(text)):
    if int(text[i])%2 == 0:
        even +=1
print(even)