#2 - Sum all number in string
text = "1423789"
sum = 0
for i in range(len(text)):
    sum += int(text[i])
print(sum)
  
