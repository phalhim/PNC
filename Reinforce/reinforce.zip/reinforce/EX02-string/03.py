#3 - Reverse number in string
text = "1423789"
print(text)