#1 - How many number in string?
text = "1423789"
for i in range(len(text)):
    print(i)