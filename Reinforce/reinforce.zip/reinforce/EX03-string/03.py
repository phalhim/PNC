#3 - Reverse string
text = "10 30 5 100 11"
print(text)