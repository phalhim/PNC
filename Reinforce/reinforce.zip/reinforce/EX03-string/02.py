#2 - Sum all number in string seperate by space Answer: 156\
text = "10 30 5 100 11"
result = list(text.split())
sum = 0
for i in range(len(result)):
    sum = sum+ int(result[i])
print(sum)


