#1 - How many number in string? Answer: 5
text = "10 30 5 100 11"
result = 0
for i in range(len(text)):
    text1=""
    if text[i]==" " or i==len(text)-1:
        if i == len(text)-1:
            text1 +=text[i]
        result+=1
        text1=""
    else:
        text1+=text[i]
print(result)