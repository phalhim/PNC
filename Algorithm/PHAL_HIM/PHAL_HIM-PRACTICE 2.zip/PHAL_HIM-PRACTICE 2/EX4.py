def getAbsolute(number):
    if number < 0:
        return -1 * number
    else:
        return number
    
print(getAbsolute(5) + 10)

