number=input()
result =0
count ="WON"
for i in range(len(number)):
    if int(number[i]) >=10 and int(number[i])<=30:
        count="LOST"
    result+=1
print(count)