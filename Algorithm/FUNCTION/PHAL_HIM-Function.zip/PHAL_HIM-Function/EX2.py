def sum(number1,number2):
    return number1+number2
number1 =int(input("Enter have number1: "))
number2 =int(input("Enter have number2: "))
print(sum(number1,number2))