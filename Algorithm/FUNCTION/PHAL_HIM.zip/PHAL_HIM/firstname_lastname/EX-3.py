reverseText = ['apple', 'banana']
res =[]
for i in range(len(reverseText)):
    for j in range(len(reverseText[i])):
        res += reverseText[i][j]
print(res)