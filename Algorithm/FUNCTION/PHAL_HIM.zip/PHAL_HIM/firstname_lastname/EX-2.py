arr = ['Meet', 'Know', 'Week', 'See', 'Eyes'] 

for i in range(len(arr)):
    for j in range(len(arr[i])):
        if arr[i][j] =="e" or arr[i][j] == "E":
            print(arr[i])