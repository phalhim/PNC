number =int(input("Enter: "))
res = "Outside"
if number >=10 or number >=20:
    res ="Inside"
print(res)
