array =[2,3,5,6]
for i in range(len(array)):
    if array[i] ==3:
        array[i]=7
print(array)