array =[11,3,4,32,3]
result = []
for i in range(len(array)):
    if array[i] <=9:
        result+=[array[i]]
print(result)