changeOfNumber = [0,1,0,0,0]
result = []
for i in range(len(changeOfNumber)):
    for j in range(len(changeOfNumber[i])):
        if changeOfNumber[i] =="R" :
            changeOfNumber[i] == 1
        elif changeOfNumber[i]:

            print(result)
