array =["Him","Rady","yon"]
print(array+["Mengmeang"])