array =["HELLOWORLD"]
result =[]
for i in range(len(array)):
    result = array[i]+","
    print(array)

