array =[4,6,3,7,4]
result =[]
for i in range(len(array)):
        if array[i]%2 !=0:
            result=int(array[i])
            print(result)