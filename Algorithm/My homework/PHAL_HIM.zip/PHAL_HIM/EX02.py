def containUpperCase(string):
    uppercase= True
    if string =="hi":
        uppercase =False
    return uppercase
string =input()
print(containUpperCase(string))