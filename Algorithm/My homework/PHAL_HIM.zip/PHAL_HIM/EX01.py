array =["dara","bopha"]
result = 0
for i in range(len(array)):
    if array[i] =="A" or "a":
        result += 1
print( result)



