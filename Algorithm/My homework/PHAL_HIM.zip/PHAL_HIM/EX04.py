number =[60,80,70]
sum = number([1])
print(sum)